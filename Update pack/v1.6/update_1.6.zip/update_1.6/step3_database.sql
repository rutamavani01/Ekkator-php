
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'superadmin', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(2, 'admin', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(3, 'teacher', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(4, 'accountant', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(5, 'librarian', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(6, 'parent', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(7, 'student', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(8, 'user', '2022-09-21 17:30:54', '2022-09-21 17:30:54'),
(9, 'alumni', '2022-09-21 17:30:54', '2022-09-21 17:30:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

