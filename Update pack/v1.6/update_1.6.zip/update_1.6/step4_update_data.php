//database migration
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

if (!Schema::hasColumn('users', 'status')) {
    Schema::table('users', function (Blueprint $table1) {
        $table1->string('status');
    });
}

$data['key'] = 'white_logo';
$data['value'] = ' 	16864783704.png';
DB::table('global_settings')->insert($data);

$data['key'] = 'navbar_title';
$data['value'] = 'ekattor8';
DB::table('global_settings')->insert($data);

