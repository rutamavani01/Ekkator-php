<div class="calendar-body">
  <div id='top'>
    {{ get_phrase('Locales:') }}
    <select id='locale-selector'></select>
  </div>
  <div id="calendar" class="notice-calendar-section"></div>
</div>