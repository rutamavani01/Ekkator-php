<div>
	<img src="{{ asset('assets/csv_file/csv_file.jpg') }}" width="100%" >
</div>